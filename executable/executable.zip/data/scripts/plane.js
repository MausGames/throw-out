

// ****************************************************************
cPlane.s_afVertexData =
[-35.0, -35.0, 0.0, 0.0, 0.0, 0.0,
 -35.0,  35.0, 0.0, 0.0, 0.0, 0.0,
  35.0, -35.0, 0.0, 0.0, 0.0, 0.0,
  35.0,  35.0, 0.0, 0.0, 0.0, 0.0];
                      
cPlane.s_aiIndexData =
[0, 2, 1, 1, 2, 3];

cPlane.s_sVertexShader = 
"attribute vec3 a_v3Position;"                                      +
"uniform   mat4 u_m4ModelViewProj;"                                 +
"uniform   mat4 u_m4ModelView;"                                     +
"varying   vec3 v_v3Relative;"                                      +
"varying   vec2 v_v2Border;"                                        +
""                                                                  +
"void main()"                                                       +
"{"                                                                 +
"    v_v3Relative = (u_m4ModelView * vec4(a_v3Position, 1.0)).xyz;" +
"    v_v2Border   = a_v3Position.xy;"                               +
""                                                                  +
"    gl_Position  = u_m4ModelViewProj * vec4(a_v3Position, 1.0);"   +
""                                                                  +
"}";

cPlane.s_sFragmentShader =
"precision mediump float;"                                            +
""                                                                    +
"varying vec3 v_v3Relative;"                                          +
"varying vec2 v_v2Border;"                                            +
""                                                                    +
"void main()"                                                         +
"{"                                                                   +
"    const vec3 v3Camera = vec3(0.0, 0.447213650, -0.894427299);"     +
""                                                                    +
"    float fIntensity = 40.0 / length(v_v3Relative);"                 +
"    fIntensity      *= dot(normalize(v_v3Relative), v3Camera);"      +
"    fIntensity       = (fIntensity + 0.25)*1.05;"                    +
""                                                                    +
"    vec2 v2Border = vec2(35.0, 35.0) - abs(v_v2Border);"             +
"    float fValue  = min(min(v2Border.x, v2Border.y)*0.5+0.25, 1.0);" +
""                                                                    +
"    gl_FragColor = vec4(vec3(fIntensity*fValue), 1.0);"              +
"}";


// ****************************************************************
cPlane.s_pModel  = null;
cPlane.s_pShader = null;


// ****************************************************************
cPlane.Init = function()
{
    // define model and shader-program
    cPlane.s_pModel  = new cModel(cPlane.s_afVertexData, cPlane.s_aiIndexData);
    cPlane.s_pShader = new cShader(cPlane.s_sVertexShader, cPlane.s_sFragmentShader);
};


// ****************************************************************
function cPlane()
{
}


// ****************************************************************
cPlane.prototype.Render = function()
{
    // enable the shader-program
    cPlane.s_pShader.Enable();

    // calculate model-view matrices
    var mModelViewProj = mat4.create();
    mat4.mul(mModelViewProj, g_mProjection, g_mCamera);

    // update all object uniforms
    GL.uniformMatrix4fv(cPlane.s_pShader.m_iUniformModelViewProj, false, mModelViewProj);
    GL.uniformMatrix4fv(cPlane.s_pShader.m_iUniformModelView,     false, g_mCamera);

    // render the model
    cPlane.s_pModel.Render();
};


// ****************************************************************
cPlane.prototype.Move = function()
{
};